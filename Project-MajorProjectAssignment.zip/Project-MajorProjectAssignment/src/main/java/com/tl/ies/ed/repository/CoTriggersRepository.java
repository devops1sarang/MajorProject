package com.tl.ies.ed.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.ed.entity.CoTriggersEntity;


public interface CoTriggersRepository extends JpaRepository<CoTriggersEntity, Serializable>{

	public List<CoTriggersEntity> findByTrgStatus(String trgStatus);
	
	
}
