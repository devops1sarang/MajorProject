package com.tl.ies.ar.exceptions;

public class NoSSNFoundException extends RuntimeException {

	public NoSSNFoundException(String msg) {
		super(msg);
	}
}
