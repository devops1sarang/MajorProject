package com.tl.ies.ed.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.ed.entity.EligibilityDetEntity;

public interface EligibilityDetRepository extends JpaRepository<EligibilityDetEntity, Serializable> {

}
