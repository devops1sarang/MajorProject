package com.tl.ies.ar.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.ar.entity.ApplicationRegistrationEntity;

public interface ApplicationRegRepository extends JpaRepository<ApplicationRegistrationEntity, Serializable> {

}
