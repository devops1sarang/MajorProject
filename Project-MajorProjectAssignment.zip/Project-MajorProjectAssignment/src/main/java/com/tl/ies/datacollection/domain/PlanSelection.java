package com.tl.ies.datacollection.domain;



import com.tl.ies.ar.domain.ApplicationRegistration;

import lombok.Data;
@Data
public class PlanSelection {

	private Integer planId;
	
	  private Integer caseNo; 
	  private String firstName; 
	  private String lastName;
	  private ApplicationRegistration appreg;
	  private String planName;
	  private String empStatus;
	  private String income;
}
