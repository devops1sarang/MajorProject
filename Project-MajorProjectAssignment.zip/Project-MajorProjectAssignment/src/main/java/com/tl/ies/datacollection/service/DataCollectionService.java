package com.tl.ies.datacollection.service;

import java.util.Map;

import com.tl.ies.datacollection.domain.ChildDetails;
import com.tl.ies.datacollection.domain.CreateCase;
import com.tl.ies.datacollection.domain.IncomeDetails;
import com.tl.ies.datacollection.domain.PlanSelection;

public interface DataCollectionService {

	public CreateCase createCase(CreateCase datac);
	
	public CreateCase applicationRegData(String applicationId);
	
	public Map<Integer, String> getPlansFrmPlanMdl();
	
	public PlanSelection CreateSelectedPlan(PlanSelection plan);
	
	public ChildDetails childDetails(ChildDetails child);
	
	public boolean incomeDetails(IncomeDetails income);
	
}
