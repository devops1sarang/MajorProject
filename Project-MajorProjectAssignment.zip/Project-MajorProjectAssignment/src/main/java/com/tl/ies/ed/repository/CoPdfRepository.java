package com.tl.ies.ed.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.ed.entity.CoPdfEntity;

public interface CoPdfRepository extends JpaRepository<CoPdfEntity, Serializable> {

}
