package com.tl.ies.datacollection.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.datacollection.entity.ChildDetailsEntity;

public interface ChildDetailsRepository extends JpaRepository<ChildDetailsEntity, Serializable> {

}
