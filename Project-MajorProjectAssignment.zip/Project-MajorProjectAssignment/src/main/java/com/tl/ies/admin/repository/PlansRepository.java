package com.tl.ies.admin.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.admin.entity.AccountEntity;
import com.tl.ies.admin.entity.PlanEntity;

public interface PlansRepository extends JpaRepository<PlanEntity, Serializable> {

	

}
