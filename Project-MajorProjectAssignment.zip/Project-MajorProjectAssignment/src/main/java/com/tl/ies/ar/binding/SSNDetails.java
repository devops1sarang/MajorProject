package com.tl.ies.ar.binding;

import lombok.Data;

@Data
public class SSNDetails {

	private String ssnNO;

	private String firstName;

	private String lastName;

	private String gender;

	private String dob;

	private String stateName;
}
