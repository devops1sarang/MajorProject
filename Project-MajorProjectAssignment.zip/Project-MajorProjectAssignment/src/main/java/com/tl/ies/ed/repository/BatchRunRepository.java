package com.tl.ies.ed.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tl.ies.ed.entity.BatchRunEntity;

public interface BatchRunRepository extends JpaRepository<BatchRunEntity, Serializable> {

	
	
}
